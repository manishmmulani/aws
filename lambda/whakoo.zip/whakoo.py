def create_menu_item(event, context):
    print("Creating a menu item", event, context)
    # TODO implement adding menu item to aurora
    print("Menu item created")

def get_menu_items(event, context):
    print("Obtaining menu items", event, context)
    # TODO implement getting menu items from aurora
    print("Menu items obtained")
    return {"id":1, "title":"Default Item"}


